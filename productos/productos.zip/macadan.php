<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link href="../css/producto.css" rel="stylesheet" type="text/css"  />
</head>
<body>
	<div id="mainprod">
       <div id="izq">
            	<div id="parrafo" style="padding-top:5%">
            <p id="prod">MACADAN (31'5/63)<br/>
            <span class="descr"><p class="parrafo" style="font-weight:bold;">Certificado para:</p>
                    <ul>
                        <li><p class="parrafo">Capas granulares y capas tratadas con conglomerantes hidr&aacute;ulicos para su uso en capas estructurales de firmes.</p></li>
               		</ul>
                </div>
            </span>
            </p>
        </div>
        <div id="der">
            <div id="mainimg"><img src="./img/productos/macadan.jpg" alt="Macadan 31'5/63" width="600" height="338"/></div>
        </div>
    </div>
</body>

</html>