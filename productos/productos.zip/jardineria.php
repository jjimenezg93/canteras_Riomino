<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link href="../css/producto.css" rel="stylesheet" type="text/css"  />
</head>
<body>
	<div id="mainprod">
    	<div id="izq">
            	<div id="parrafo" style="padding-top:5%">
            <p id="prod">JARDINER&Iacute;A<br/>
            <span class="descr"><p class="parrafo" style="font-weight:bold;">Contactar para m&aacute;s informaci&oacute;n</p>
                </div>
            </span>
            </p>
        </div>
        <div id="der">
            <div id="mainimg"><img src="./img/productos/olivos.jpg" alt="Olivos" width="600" height="338"/></div>
        </div>
    </div>
</body>

</html>