<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link href="../css/producto.css" rel="stylesheet" type="text/css"  />
    
</head>
<body>
        <!-- contenedor -->
        <div id="cont_prod">
        	<div id="izq">
                <div id="parrafo">
                    <ul style="padding-top:5%; font-size: 20px; text-align:left; font-family: 'Open Sans', sans-serif;">
                        <li><p>ISO 9001 y marcado CE</p></li>
                        <li><p>B&aacute;scula calibrada y certificada</p></li>
                        <li><p>Instalaci&oacute;n y maquinaria certificada seg&uacute;n normativa CE</p></li>
                        <li><p>Personal altamente cualificado y formado</p></li>
                        <li><p>Implicaci&oacute;n y compromiso con el medio ambiente</p></li>
                        <li><p>Recepci&oacute;n de materiales inertes procedentes de destierros</p></li>
                    </ul>
				</div>
                </p>
            	
            </div>
            <div id="der">
	        	<div id="mainimg"><img src="./img/productos/montanas_material.jpg" alt="applus" />
                    <img class="certificate" src="./img/productos/applus.png" alt="applus" />
                    <img class="certificate" src="./img/productos/ce.png" alt="ce" />
				</div>
            </div>
        </div>
</body>

</html>